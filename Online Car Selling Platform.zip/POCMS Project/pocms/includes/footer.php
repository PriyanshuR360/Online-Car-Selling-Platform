    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="inner-content">
              <p>Copyright © <?php echo date('Y');?> Preowned Car Selling Portal </p>
            </div>
          </div>
        </div>
      </div>
    </footer>