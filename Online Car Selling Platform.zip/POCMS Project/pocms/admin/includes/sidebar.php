<aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu">
          <li class="active">
            <a class="" href="dashboard.php">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
          </li>
   
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_desktop"></i>
                          <span>Company Info</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="add-carcompany.php">Add Company</a></li>
              <li><a class="" href="manage-carcompany.php">Manage Company</a></li>
             
            </ul>
          </li>
                <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>Car Info</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="add-cardetail.php">Add Car Details</a></li>
              <li><a class="" href="manage-cardetail.php">Manage Car Details</a></li>
            </ul>
          </li>
          

          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_table"></i>
                          <span>Enquiry</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="unanswer-enquiry.php">Unanswer Enquiry</a></li>
              <li><a class="" href="answer-enquiry.php">Answered Enquiry</a></li>
            </ul>
          </li>
<li>
            <a class="" href="search.php">
                          <i class="icon_genius"></i>
                          <span>Search Enquiry</span>
                      </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_documents_alt"></i>
                          <span>Pages</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="aboutus.php"><span>About Us</span></a></li>
              <li><a class="" href="contactus.php"><span>Contact Us</span></a></li>
              
            </ul>
          </li>

        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>