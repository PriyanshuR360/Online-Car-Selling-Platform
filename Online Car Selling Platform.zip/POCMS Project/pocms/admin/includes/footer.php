 <div class="text-right">
        <div class="credits">
        <p>© <?php echo date('Y');?> Pre Owned / Used Car Sell Portal . All rights reserved.</p>
        </div>
      </div>